%-------------------------------------------------------------------------%
% KEPLER.m
%-------------------------------------------------------------------------%
% INPUTS:
% pos  - position vector in ECI frame.(km)
% vel  - velocity vector in ECI frame.(km/s)
% input     struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0)
% constants struct('mu',398600.4415,'J2',0.00108263,'Re',6378.1363,'f',0.00335)
% parameter struct('tsmatrix',0,'tsmatrixdot',0);
% OUTPUTS:
% deriv - accelaration due to two-body.(km/s^2)
%
% NOTES:
% *This function computes accelaration due to two-body.
% *This function does not use vel,input,parameter. They are exist because
% a standard input format is used for all force functions.(KEPLER,J2force,DRAGFORCE,THRUST)
%
% Last modified: 13/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ deriv ] = KEPLER(pos,vel,input,constants,parameter)
accel=(-constants.mu*pos)/norm(pos)^3;
deriv=[accel(1) accel(2) accel(3)];
end

