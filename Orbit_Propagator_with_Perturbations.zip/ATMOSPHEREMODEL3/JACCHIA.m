%-------------------------------------------------------------------------%
% Copyright (c) 2013, David Eagle
% All rights reserved.
%-------------------------------------------------------------------------%
% JACCHIA.m
%-------------------------------------------------------------------------%
% INPUTS:
% input struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0)
% long - geodetic longitude of satellite.(degree)
% lat  - geodetic latitude of satellite.(degree)
% alt  - geodetic altitude of satellite.(km)
% OUTPUTS:
% dens - atmospheric density.(kg/m^3)
% 
% NOTES:
% *This JACCHIA70 atmosphere model is implemented by David Eagle but it is
% modified.(https://www.mathworks.com/matlabcentral/fileexchange/41752-a-matlab-implementation-of-the-jacchia-atmosphere-model)
% *Correctness of this model is not checked because there is not 
% any application or web site that provide reference density values. 
% 
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ dens ] = JACCHIA(input,long,lat,alt)

rtd = 180.0 / pi;

dtr = pi / 180.0;

% initialize the algorithm

j70iniz;

% algorithm inputs

%  indata(1)  = geodetic altitude (kilometers)
%  indata(2)  = geodetic latitude (radians)
%  indata(3)  = geographic longitude (radians)
%  indata(4)  = calendar year (all digits)
%  indata(5)  = calendar month
%  indata(6)  = calendar day
%  indata(7)  = utc hours
%  indata(8)  = utc minutes
%  indata(9)  = geomagnetic index type
%               (1 = indata(12) is Kp, 2 = indata(12) is Ap)
%  indata(10) = solar radio noise flux (jansky)
%  indata(11) = 162-day average F10 (jansky)
%  indata(12) = geomagnetic activity index

indata(1) = alt;
indata(2) = lat * dtr;
indata(3) = long * dtr;
indata(4) = input.datetime(1);
indata(5) = input.datetime(2);
indata(6) = input.datetime(3);
indata(7) = input.datetime(4);
indata(8) = input.datetime(5);
indata(9) = 2;

[b,e] = size(input.sw);
for i=1:e
    if ( (indata(4)==input.sw(1,i)) && (indata(5)==input.sw(2,i)) && (indata(6)==input.sw(3,i)) )
        swdatas = input.sw(:,i);
        break;
    end
end

if input.F107==0 && input.F107A==0 && input.magnetindex==0
    indata(10)=swdatas(31);
    indata(11)=swdatas(33);
    indata(12)=swdatas(23);
else
    indata(10)=input.F107;
    indata(11)=input.F107A;
    indata(12)=input.magnetindex;
end

day = indata(6) + indata(7) / 24.0 + indata(8) / 1440.0;

jdate = julian(indata(5), day, indata(4));

[cdstr,utstr] = jd2str(jdate);

% compute atmospheric properties

outdata = jatmos70(indata);

% algorithm outputs

%  outdata(1)  = exospheric temperature (deg K)
%  outdata(2)  = temperature at altitude (deg K)
%  outdata(3)  = N2 number density (per meter-cubed)
%  outdata(4)  = O2 number density (per meter-cubed)
%  outdata(5)  = O number density (per meter-cubed)
%  outdata(6)  = A number density (per meter-cubed)
%  outdata(7)  = He number density (per meter-cubed)
%  outdata(8)  = H number density (per meter-cubed)
%  outdata(9)  = average molecular weight
%  outdata(10) = total density (kilogram/meter-cubed)
%  outdata(11) = log10(total density)
%  outdata(12) = total pressure (pascals)

dens=outdata(10);

end

