%-------------------------------------------------------------------------%
% Copyright (c) 2017, Meysam Mahooti
% All rights reserved.
%-------------------------------------------------------------------------%
% MSISE86.m
%-------------------------------------------------------------------------%
% INPUTS:
% input struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0)
% glong - geodetic longitude of satellite.(degree)
% glat  - geodetic latitude of satellite.(degree)
% alt   - altitude of satellite.(km)
% OUTPUTS:
% dens - atmospheric density.(g/cm^3)
% 
% NOTES:
% *This MSISE86 atmosphere model is implemented by Meysam Mahooti but it is
% modified.(https://www.mathworks.com/matlabcentral/fileexchange/65117-msis-86-atmosphere-model)
% *Correctness of this model is not checked because there is not 
% any application or web site that provide reference density values. 
%
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%


function [ rho ] = MSISE86(input,glong,glat,alt )

format long g

ap=zeros(7,1);
year=input.datetime(1);month=input.datetime(2);day=input.datetime(3);hour=input.datetime(4);min=input.datetime(5);sec=input.datetime(6);
Mjd_UTC = Mjday(year,month,day,hour,min,sec);

[year, mon, day, hour, min, sec] = invjday (Mjd_UTC+2400000.5);
[days] = finddays (year, mon, day, hour, min, sec);


iday = floor(days);
sec  = hour*3600+min*60+sec;     % seconds in day (UT)
stl	 = sec/3600+glong/15;	    % local solar time in hours

[b,e] = size(input.sw);
for i=1:e
    if ( (year==input.sw(1,i)) && (mon==input.sw(2,i)) && (day==input.sw(3,i)) )
        swdatas = input.sw(:,i);
        break;
    end
end

if input.F107==0 && input.F107A==0 && input.magnetindex==0
    f107=swdatas(31);
    f107a=swdatas(33);
    ap(1)=swdatas(23);
else
    f107=input.F107;
    f107a=input.F107A;
    ap(1)=input.magnetindex;
end

[d,t] = msis86(iday, sec, alt, glat, glong, stl, f107a, f107, ap);
rho=d(6);
end