%-------------------------------------------------------------------------%
% ORBIT PROPAGATOR WITH PERTURBATIONS
%-------------------------------------------------------------------------%
% Total 9 Files:
% test_orbitpropagator.m - test function
% SW.txt                 - space weather file from celestrack.(https://celestrak.com/)
% EOP.txt                - earth orientation parameters from celestrack.(https://celestrak.com/)
% PROPAGATOR             - orbit propagator.
% FORCES                 - forces that are applied on satellite.
% ECITOECEF              - ECI to ECEF coordinate transformation.(MEYSAM MAHOOTI's code from MATLAB file exchange)(https://www.mathworks.com/matlabcentral/fileexchange/61957-icrs-itrs-transformation)
% ATMOSPHERE MODEL       - NRLMSISE00 atmosphere model for density calculation.(MEYSAM MAHOOTI's code from MATLAB file exchange)(https://www.mathworks.com/matlabcentral/fileexchange/56253-nrlmsise-00-atmosphere-model)
% ATMOSPHERE MODEL2      - MSIS86 atmosphere model for density calculation.(MEYSAM MAHOOTI's code from MATLAB file exchange)(https://www.mathworks.com/matlabcentral/fileexchange/65117-msis-86-atmosphere-model)
% ATMOSPHERE MODEL3      - JACCHIA70 atmosphere model for density calculation.(DAVID EAGLE's code from MATLAB file exchange)(https://www.mathworks.com/matlabcentral/fileexchange/41752-a-matlab-implementation-of-the-jacchia-atmosphere-model)
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
% test_orbitpropagator.m
%-------------------------------------------------------------------------%
%
% INPUTS:
% input.position         - position vector of satellite in ECI frame.(km)
% input.velocity         - velocity vector of satellite in ECI frame.(km/s)
% input.timestep         - timestep of numeric integrator.(sec)
% input.propagationtime1 - propagation time when thruster is off.(sec)
% input.propagationtime2 - propagation time when thruster is on.(sec)
% input.datetime         - epoch time in UTC gregorian.([year month day hour min sec])
% input.eop              - earth orientation parameters.
% input.atmosmodel       - atmosphere models.
%  Options:
%       input.atmosmodel='NRLMSISE_00'
%       input.atmosmodel='JACCHIA'
%       input.atmosmodel='MSISE86'
% input.sw               - space weather datas.
% input.F107             - manually entered daily observed solar flux at 10.7 wavelength.(W/m^2)
% input.F107A            - manually entered last 3 month averaged solar flux at 10.7 wavelenght.(W/m^2)
% input.magnetindex      - manually entered daily averaged ap value.
% input.drymass          - dry mass of satellite.(kg)
% input.cd               - drag coefficient of satellite.
% input.dragarea         - cross sectional area of satellite.(m^2)
% input.THRUSTER         - whether thrust is used or not during the propagation.
%  Options:
%       input.THRUSTER='ON'
%       input.THRUSTER='OFF'
% input.fuelmass         - mass of fuel with the assumption of no fuel reduction.(kg)
% input.thrustmag        - thrust magnitude with the assumption of constant thrust.(Newton)
% input.beforethrust     - propagation time before the thrust.(sec)
% input.afterthrust      - propagation time after the thrust.(sec)
% input.thrustduration   - thrust duration.(sec)
% input.thrusttimestep   - timestep of numeric integrator when thrust is applied.(sec)
% forces                 - forces that are applied on satellite.
%  Options:
%       forces=["KEPLER"]
%       forces=["KEPLER","J2force"]
%       forces=["KEPLER","DRAGFORCE"]
%       forces=["KEPLER","DRAGFORCE","J2force"]
% Tforces                - forces that are applied on satellite during the thrust. 
%  Options:
%       Tforces=["KEPLER","THRUST"]
%       Tforces=["KEPLER","THRUST","DRAGFORCE"]
%       Tforces=["KEPLER","THRUST","J2force"]
%       Tforces=["KEPLER","THRUST","DRAGFORCE","J2force"]
%
% CONSTANTS
% constants.mu           - gravitational parameter.(km^3/s^2)
% constants.J2           - second zonal harmonic.
% constants.Re           - radius of earth.(km)
% constants.f            - earth's flattening.
%
% OUTPUTS:
% out.X                  - X components of position vector in ECI frame during the propagation.(km)
% out.Y                  - Y components of position vector in ECI frame during the propagation.(km)
% out.Z                  - Z components of position vector in ECI frame during the propagation.(km)
% out.VX                 - X components of velocity vector in ECI frame during the propagation.(km/s)
% out.VY                 - Y components of velocity vector in ECI frame during the propagation.(km/s)
% out.VZ                 - Z components of velocity vector in ECI frame during the propagation.(km/S)
% out.longitude          - longitudes of satellite during the propagation.(degree)
% out.latitude           - latitudes of satellite during the propagation.(degree)
% out.altitude           - altitudes of satellite during the propagation.(km)
% 3D orbit view
%
% NOTES: 
% *Add to path all folder in order to run the code.
% *Update the EOP.txt and SW.txt files from the celestrak according to your epoch date and propagate duration.
% *If input.F107=0, input.F107A=0, input.magnetindex=0 then these values are taken from the space weather file.
% *Care about the below conditions are satisfied or not, otherwise outputs may be wrong.
%   1)input.Propagationtime1,input.beforethrust,input.afterthrust and input.timestep should satisfy below condition:
%      mod(input.propagationtime1,input.timestep)=0,mod(input.beforethrust,input.timestep)=0,mod(input.afterthrust,input.timestep)=0
%   2)input.thrusttimestep and input.thrustduration should satisfy below condition:
%      mod(input.thrustduration,input.thrusttimestep)=0
% *It is recommended that generally use: input.thrusttimestep=1
% *Thrust is applied in the velocity direction.(Constant thrust assumption) 
%
% Last Modified: 10/02/2019  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

clc;clear;
format long

eop     = fopen('EOP.txt','r');
eopdata = fscanf(eop,'%i %d %d %i %f %f %f %f %f %f %f %f %i',[13 inf]);
fclose(eop);

sw     = fopen('SW.txt','r');
swdata = fscanf(sw,'%4i %3d %3d %5i %3i %3i %3i %3i %3i %3i %3i %3i %3i %4i %4i %4i %4i %4i %4i %4i %4i %4i %4i %4f %2i %4i %6f %2i %6f %6f %6f %6f %6f',[33 inf]);
fclose(sw);

m2tokm2 = 1/1000000;
mtokm   = 1/1000;

input=struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0);
constants=struct('mu',398600.4415,'J2',0.00108263,'Re',6378.1363,'f',0.00335);
output=struct('X',0,'Y',0,'Z',0,'VX',0,'VY',0,'VZ',0,'longitude',0,'latitude',0,'altitude',0);

%Required inputs for both cases(input.THRUSTER='ON'/input.THRUSTER='OFF')
input.THRUSTER='OFF';
forces=["KEPLER","J2force","DRAGFORCE"];
input.position=[-1519.15511195 -6708.27307879 2.93887057247];
input.velocity=[-0.94223805963  0.21668722335 7.55096266938];
input.timestep=120;
input.datetime=[2015 7 1 12 0 0];
input.eop=eopdata;
input.sw=swdata;
input.atmosmodel='MSISE86';
input.F107=0;
input.F107A=0;
input.magnetindex=0;
input.drymass=4;
input.cd=2.2;
input.dragarea=0.01;
input.dragarea=input.dragarea*m2tokm2;
%If input.THRUSTER='OFF',enter below parameter and run the code
input.propagationtime1=86400*7;
%If input.THRUSTER='ON',enter below parameters and run the code
Tforces=["KEPLER","THRUST"];
input.fuelmass=1;
input.thrustmag=1;
input.thrustmag=input.thrustmag*mtokm;
input.thrustduration=30;
input.thrusttimestep=1;
input.beforethrust=86400*5;
input.afterthrust=86400*5;
input.propagationtime2=input.beforethrust+input.afterthrust+input.thrustduration;

[out]=orbitpropagator(input,output,constants,forces,Tforces);

%---------------------------- 3D ORBIT -----------------------------------%
[x,y,z]=sphere(50);
coord=[0 0 0 6378];
s=surf(x*coord(4)+coord(1),y*coord(4)+coord(2),z*coord(4)+coord(3));
hold on
plot3(out.X,out.Y,out.Z,'.k','MarkerSize',5);
%---------------------------- 3D ORBIT -----------------------------------%
