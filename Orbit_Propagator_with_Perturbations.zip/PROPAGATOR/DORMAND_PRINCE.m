%-------------------------------------------------------------------------%
% DORMAND_PRINCE.m
%-------------------------------------------------------------------------%
% INPUTS:
% state     - state vectors in ECI frame.(km and km/s)
% forces
% dt        - timestep.
% input      struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0) 
% constants  struct('mu',398600.4415,'J2',0.00108263,'Re',6378.1363,'f',0.00335)
% parameter  struct('tsmatrix',0,'tsmatrixdot',0)
%
% OUTPUTS:
% statefinal - final state vectors in ECI frame at each integration.(km and km/s)
% 
% NOTES:
% *This function is numerically integrate the equation of motion.
% *Dormand&Prince coefficients are found from the "Journal of Computational and
% Applied Mathematics, volume 6, no 1, 1980" and also in NASA GMAT source
% code.
% 
% Last Modified: 13/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ statefinal ] = DORMAND_PRINCE(state,forces,dt,input,constants,parameter)

accel=0;
pos=[state(1) state(2) state(3)];
vel=[state(4) state(5) state(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k1=[vel accel];

accel=0;
state1=state+2/9*k1*dt;
pos=[state1(1) state1(2) state1(3)];
vel=[state1(4) state1(5) state1(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k2=[vel accel];

accel=0;
state2=state+1/12*k1*dt+1/4*k2*dt;
pos=[state2(1) state2(2) state2(3)];
vel=[state2(4) state2(5) state2(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k3=[vel accel];

accel=0;
state3=state+55/324*k1*dt-25/108*k2*dt+50/81*k3*dt;
pos=[state3(1) state3(2) state3(3)];
vel=[state3(4) state3(5) state3(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k4=[vel accel];

accel=0;
state4=state+83/330*k1*dt-13/22*k2*dt+61/66*k3*dt+9/110*k4*dt;
pos=[state4(1) state4(2) state4(3)];
vel=[state4(4) state4(5) state4(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k5=[vel accel];

accel=0;
state5=state-19/28*k1*dt+9/4*k2*dt+1/7*k3*dt-27/7*k4*dt+22/7*k5*dt;
pos=[state5(1) state5(2) state5(3)];
vel=[state5(4) state5(5) state5(6)];
for i=1:length(forces)
accel=feval(forces(i),pos,vel,input,constants,parameter)+accel;
end
k6=[vel accel];

statefinal=state+(19/200*k1+3/5*k3-243/400*k4+33/40*k5+7/80*k6)*dt;
end

