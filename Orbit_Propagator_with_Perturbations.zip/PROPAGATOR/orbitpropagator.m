%-------------------------------------------------------------------------%
% orbitpropagator.m
%-------------------------------------------------------------------------%
% INPUTS:
% input     struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0)
% output    struct('X',0,'Y',0,'Z',0,'VX',0,'VY',0,'VZ',0,'longitude',0,'latitude',0,'altitude',0)
% constants struct('mu',398600.4415,'J2',0.00108263,'Re',6378.1363,'f',0.00335)
% string forces
% string Tforces
%
% PARAMETER:
% tsmatrix     - transformation matrix from ECI to ECEF.
% tsmatrixdot  - time derivative of transformation matrix from ECI
% to ECEF.(It is used for transformation of velocity from ECI to ECEF.)
%
% OUTPUTS:
% output    struct('X',0,'Y',0,'Z',0,'VX',0,'VY',0,'VZ',0,'longitude',0,'latitude',0,'altitude',0)
%
% NOTES:
% *This function propagates the orbit.
% *Propagation Algorithm: 
%   1. Initial ECI2ECEF transformation matrixes are computed before the loop.
%   In the loop;
%   2. Solving equation of motion with numeric integarator.
%   3. Obtain current time.
%   4. Compute ECI2ECEF transformation matrixes.
%   5. Compute position vector in ECEF.
%   6. Compute longitude,latitude and altitude.
%
% Last Modified: 10/02/2019  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [output] = orbitpropagator(input,output,constants,forces,Tforces)

parameter=struct('tsmatrix',0,'tsmatrixdot',0);
[parameter.tsmatrix,parameter.tsmatrixdot]=ECI2ECEF(input.datetime,input.eop);

time=0;
dt=input.timestep;
pos=input.position;
vel=input.velocity;
state=[pos vel];
i=1;

switch input.THRUSTER
    case 'ON'
        tf=input.propagationtime2;
        while time<tf
            if time>=input.beforethrust && time<(input.beforethrust+input.thrustduration)
            dt=input.thrusttimestep;
            state=DORMAND_PRINCE(state,Tforces,dt,input,constants,parameter);
            else
            dt=input.timestep;
            state=DORMAND_PRINCE(state,forces,dt,input,constants,parameter);
            end
            input.datetime=DATE_TIME(input.datetime,dt);
            [parameter.tsmatrix,parameter.tsmatrixdot]=ECI2ECEF(input.datetime,input.eop);
            pos=[state(1) state(2) state(3)];
            ecefp=parameter.tsmatrix*pos';
            [long,lat,alt]=long_lat_alt(ecefp,constants);
            longitude(i)=long;latitude(i)=lat;altitude(i)=alt;
            satx(i)=state(1);saty(i)=state(2);satz(i)=state(3);
            satvx(i)=state(4);satvy(i)=state(5);satvz(i)=state(6);
            i=i+1;
            time=time+dt;
        end
    case 'OFF'
        tf=input.propagationtime1;
        while time<tf
            state=DORMAND_PRINCE(state,forces,dt,input,constants,parameter);
            input.datetime=DATE_TIME(input.datetime,dt);
            [parameter.tsmatrix,parameter.tsmatrixdot]=ECI2ECEF(input.datetime,input.eop);
            pos=[state(1) state(2) state(3)];
            ecefp=parameter.tsmatrix*pos';
            [long,lat,alt]=long_lat_alt(ecefp,constants);
            longitude(i)=long;latitude(i)=lat;altitude(i)=alt;
            satx(i)=state(1);saty(i)=state(2);satz(i)=state(3);
            satvx(i)=state(4);satvy(i)=state(5);satvz(i)=state(6);
            i=i+1;
            time=time+dt;
        end
end

output.X=satx';
output.Y=saty';
output.Z=satz';
output.VX=satvx';
output.VY=satvy';
output.VZ=satvz';
output.longitude=longitude';
output.latitude=latitude';
output.altitude=altitude';

end

