%-------------------------------------------------------------------------%
% Copyright (c) 2017, Meysam Mahooti
% All rights reserved.
%-------------------------------------------------------------------------%
% ECI2ECEF.m
%-------------------------------------------------------------------------%
% INPUTS:
% date        - current time in UTC gregorian.([year month day hour min sec])
% eop         - earth orientation parameters.
% OUTPUTS:
% tsmatrix    - transformation matrix from ECI to ECEF.
% tsmatrixdot - time derivative of transformation matrix from ECI to EEF.
% 
% NOTES:
% *This ECI to ECEF tranformation matrix computation is implemented by
% Meysam Mahooti but it is modified.(https://www.mathworks.com/matlabcentral/fileexchange/61957-icrs-itrs-transformation)  
%
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%--------------------------------------------------------------------------
%-------------------------------------------------------------------------%
function [tsmatrix,tsmatrixdot]=ECI2ECEF(date,eop)
format long g

SAT_Const

% Earth Orientation Parameters (UT1-UTC[s],UTC-TAI[s], x["], y["])
% (from IERS Bulletin B #135 and C #16; valid for 1999/03/04 0:00 UTC)
mj=Mjday(date(1),date(2),date(3),date(4),date(5),date(6));
mj = round(mj);
nop = length(eop);
for i=1:nop
    if (mj==eop(4,i))
        eop = eop(:,i);
        break;
    end
end

UT1_UTC = eop(7);      % UT1-UTC time difference [s]
TAI_UTC = eop(13);     % TAI-UTC time difference [s]
x_pole  = eop(5)/Arcs; % Pole coordinate [rad]
y_pole  = eop(6)/Arcs; % Pole coordinate [rad]

[UT1_TAI,UTC_GPS,UT1_GPS,TT_UTC,GPS_UTC] = timediff(UT1_UTC,TAI_UTC);

% Date
year=date(1);month=date(2);day=date(3);hour=date(4);min=date(5);sec=date(6);
MJD_UTC = Mjday(year,month,day,hour,min,sec);
MJD_UT1 = MJD_UTC + UT1_UTC/86400;
MJD_TT  = MJD_UTC + TT_UTC/86400;


% IAU 1976 Precession
% (ICRF to mean equator and equinox of date)
P = PrecMatrix(MJD_J2000,MJD_TT);

% IAU 1980 Nutation
% (Transformation to the true equator and equinox)
N = NutMatrix(MJD_TT);

% Apparent Sidereal Time
% Rotation about the Celestial Ephemeris Pole
[Theta,Thetadot]= GHAMatrix(MJD_UT1);   % Note: here we evaluate the equation of the
                                        % equinoxes with the MJD_UT1 time argument 
                                        % (instead of MJD_TT)
                          
% Polar motion
% (Transformation from the CEP to the IRP of the ITRS)
Pi = PoleMatrix(x_pole, y_pole);   % Note: the time argument of polar motion series
                                   % is not rigorously defined, but any differences
                                   % are negligible

tsmatrix= Pi*Theta*N*P;
tsmatrixdot=Pi*Thetadot*N*P;

end
