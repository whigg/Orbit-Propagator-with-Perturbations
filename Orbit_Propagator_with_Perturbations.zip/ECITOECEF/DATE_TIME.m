%-------------------------------------------------------------------------%
% DATE_TIME.m
%-------------------------------------------------------------------------%
% INPUTS:
% date - current time in UTC gregorian.([year month day hour min sec])
% time - time increment.(Timestep in numeric integrator)
% OUTPUTS:
% newdate - new current time in UTC gregorian after adding time increment.([year month day hour min sec])
%
% Last modified: 04/02/2019  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ newdate ] = DATE_TIME(date,time)
year=date(1);month=date(2);day=date(3);hour=date(4);min=date(5);second=date(6);

sec=second+time;

if sec>=60 
      sec1=sec;
      sec=rem(sec1,60);
      min=min+fix(sec1/60);
end
if min>=60
      min1=min;
      min=rem(min1,60);
      hour=hour+fix(min1/60);
end
if hour>=24
      hour1=hour;
      hour=rem(hour1,24);
      day=day+fix(hour1/24);
end
if month==1 && day>31
      day=day-31;
      month=month+1;
elseif month==3 && day>31 
      day=day-31;
      month=month+1;
elseif month==5 && day>31 
      day=day-31;
      month=month+1;
elseif month==7 && day>31 
      day=day-31;
      month=month+1;
elseif month==8 && day>31 
      day=day-31;
      month=month+1;
elseif month==10 && day>31 
      day=day-31;
      month=month+1;
elseif month==4 && day>30 
      day=day-30;
      month=month+1;
elseif month==6 && day>30 
      day=day-30;
      month=month+1;
elseif month==9 && day>30 
      day=day-30;
      month=month+1;
elseif month==11 && day>30  
      day=day-30;
      month=month+1;
elseif month==12 && day>31 
      day=day-31;
      month=1;
      year=year+1;
end
if month==2  
      if mod(year,4)~=0 && day>28 
        day=day-28;
        month=month+1;
      elseif mod(year,4)==0 && day>29 
        day=day-29;
        month=month+1;
      end
end
newdate=[year month day hour min sec];
end

    
      