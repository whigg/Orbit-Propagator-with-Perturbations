%-------------------------------------------------------------------------%
% Copyright (c) 2017, Meysam Mahooti
% All rights reserved.
%-------------------------------------------------------------------------%
% R_zdot.m
%-------------------------------------------------------------------------%
% INPUTS:
% angle        - angle of rotation.(rad)
% OUTPUTS:
% rotmatrixdot - time derivative of rotation matrix.
%
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ rotmatrixdot ] = R_zdot( angle )

C = cos(angle);
S = sin(angle);
rotmat = zeros(3,3);
we=7.2921159e-5;

rotmat(1,1) = -1.0*S;  rotmat(1,2) =      C;  rotmat(1,3) = 0.0;
rotmat(2,1) = -1.0*C;  rotmat(2,2) = -1.0*S;  rotmat(2,3) = 0.0;
rotmat(3,1) =    0.0;  rotmat(3,2) =    0.0;  rotmat(3,3) = 0.0;

rotmatrixdot=we*rotmat;

end

