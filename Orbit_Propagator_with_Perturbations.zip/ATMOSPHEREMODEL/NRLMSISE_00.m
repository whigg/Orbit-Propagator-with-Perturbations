%-------------------------------------------------------------------------%
% Copyright (c) 2016, Meysam Mahooti
% All rights reserved.
%-------------------------------------------------------------------------%
% NRLMSISE_00.m
%-------------------------------------------------------------------------%
% INPUTS:
% inputinitial struct('position',0,'velocity',0,'eop',0,'sw',0,'datetime',0,'drymass',0,'cd',0,'fuelmass',0,...
%    'atmosmodel',0,'dragarea',0,'timestep',0,'propagationtime1',0,'propagationtime2',0,'F107',0,'F107A',0,'magnetindex',0,...
%    'THRUSTER',0,'thrustmag',0,'beforethrust',0,'afterthrust',0,'thrustduration',0,'thrusttimestep',0)
% long  - geodetic longitude of satellite.(degree)
% lat   - geodetic latitude of satellite.(degree)
% alt   - altitude of satellite.(km)
% OUTPUTS:
% dens - atmospheric density.(kg/m^3)
% 
% NOTES:
% *This NRLMSISE00 atmosphere model is implemented by Meysam Mahooti but it is
% modified.(https://www.mathworks.com/matlabcentral/fileexchange/56253-nrlmsise-00-atmosphere-model)
% *Correctness of this model is checked with the NASA model web site(https://ccmc.gsfc.nasa.gov/modelweb/models/nrlmsise00.php)
% and results are compatible. 
% 
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ dens ] = NRLMSISE_00(inputinitial,long,lat,alt )
  
flags = struct('switches',zeros(24,1),'sw',zeros(24,1),'swc',zeros(24,1));
ap = struct('a',zeros(7,1));
input = struct('year',0,'doy',0,'sec',0,'alt',0,'g_lat',0,'g_long',0,'lst',0,'f107A',0,'f107',0,'ap',0,'ap_a',ap);

% input values
flags.switches(1)=0;
for i=2:24
    flags.switches(i)=1;
end

year=inputinitial.datetime(1);month=inputinitial.datetime(2);day=inputinitial.datetime(3);hour=inputinitial.datetime(4);min=inputinitial.datetime(5);sec=inputinitial.datetime(6);
Mjd_UTC = Mjday(year,month,day,hour,min,sec);

[year, mon, day, hour, min, sec] = invjday (Mjd_UTC+2400000.5);
[days] = finddays (year, mon, day, hour, min, sec);

input.year=0; % without effect
input.doy = floor(days);
input.sec = hour*3600+min*60+sec; % seconds in day (UT)

input.alt = alt;
input.g_lat = lat;
input.g_long = long;
input.lst=input.sec/3600+input.g_long/15;


[b,e] = size(inputinitial.sw);
for i=1:e
    if ( (year==inputinitial.sw(1,i)) && (mon==inputinitial.sw(2,i)) && (day==inputinitial.sw(3,i)) )
        swdatas = inputinitial.sw(:,i);
        break;
    end
end

if inputinitial.F107==0 && inputinitial.F107A==0 && inputinitial.magnetindex==0
    input.f107=swdatas(31);
    input.f107A=swdatas(33);
    input.ap=swdatas(23);
else
    input.f107=inputinitial.F107;
    input.f107A=inputinitial.F107A;
    input.ap=inputinitial.magnetindex;
end

% Atmospheric Density [kg/m^3]
dens = nrlmsise00(input,flags);

end

