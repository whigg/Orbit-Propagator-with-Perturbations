%-------------------------------------------------------------------------%
% long_lat_alt.m
%-------------------------------------------------------------------------%
% INPUTS:
% ecefp - position vector in ECEF.
% constants struct('mu',398600.4415,'J2',0.00108263,'Re',6378.1363,'f',0.00335)
% OUTPUTS:
% long - geodetic longitude of satellite.(degree)
% lat  - geodetic latitude of satellite.(degree)
% alt  - altitude of satellite.(km)
%
% NOTES:
% *This function computes geodetic longitude,latitude and altitude.
% *Altitude calculation is taken from https://www.mathworks.com/help/aeroblks/ecefpositiontolla.html
% 
% Last modified: 14/08/2018  �ahin Ula� K�PR�C�
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
function [ long,lat,alt ] = long_lat_alt(ecefp,constants)

X=ecefp(1);Y=ecefp(2);Z=ecefp(3);
r=norm(ecefp);
lat=asind(Z/r);
long=atand(Y/X);

if X>0 & Y>0
    long=long;
elseif X<0 & Y>0
    long=180+long;
elseif X<0 & Y<0
    long=-180+long;
else
    long=long;
end

s=sqrt(X^2+Y^2);
e2=1-(1-constants.f)^2;
N=constants.Re/sqrt(1-e2*sind(lat)^2);
alt=s*cosd(lat)+(Z+e2*N*sind(lat))*sind(lat)-N;

end

